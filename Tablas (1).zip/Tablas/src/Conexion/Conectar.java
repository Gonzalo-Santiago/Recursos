/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Conexion;
import java.sql.*;

/**
 *
 * @author $
 */
public class Conectar {
  public static  Connection c;   
  private static Connection c2;
  public static Connection server_con;
  public static String MENSAJE="";
  private String host="aulavirtual.unsis.edu.mx";
  private String dbname="info2023";
  private String passwd="506";
    
  
  public java.sql.Connection conectaServidor(){
        try {
            MENSAJE="";
            String url = "jdbc:mysql://"+host;
            Class.forName("com.mysql.jdbc.Driver");
            server_con=java.sql.DriverManager.getConnection(url,"grupo506",passwd);
            System.out.println(url);
        } catch (Exception ex) {
            MENSAJE=ex.getMessage();
        }
        return server_con;
    }
    public void creaBD(String stm){
        try {
            MENSAJE="";
            c2 = server_con;
            Statement s = c2.createStatement();
            s.executeUpdate(stm);
            c2.close();
        } catch (Exception ex) {
            MENSAJE=ex.getMessage();
        }
    }
    public java.sql.Connection conectaBD(){
        String url="jdbc:mysql://"+host+"/"+dbname;
        MENSAJE="";
        try{
            Class.forName("com.mysql.jdbc.Driver");
            c=DriverManager.getConnection(url,"grupo506",passwd);
            System.out.println(url);
        }catch(Exception ex) {MENSAJE=ex.getMessage();System.out.println(MENSAJE);}        
        return c;
    }
    public java.sql.ResultSet consulta(String consul){
        java.sql.ResultSet r=null;
        MENSAJE="";
        try {
                java.sql.Statement stm= c.createStatement();
                r = stm.executeQuery(consul);
            }catch(SQLException e)
                    {MENSAJE=e.getMessage();}
            return r;
    }
    public void ejecutar(String stm){
        try{
            MENSAJE="";
            Statement s=c.createStatement();
            s.executeUpdate(stm);
        }catch(Exception e ){  MENSAJE=e.getMessage();}
    }
}
