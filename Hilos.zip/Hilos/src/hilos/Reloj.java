
package hilos;


public class Reloj extends javax.swing.JFrame {
    private int horas;
    private int minutos;
    private int segundos;
   

    public Reloj() {
        initComponents();
        /**
         *  Esta línea crea un nuevo objeto Thread llamado t.
         * Está utilizando una expresión lambda this::run,
         * que hace referencia al método run()
         */
        Thread t = new Thread(this::run);
        t.start();
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtHora = new javax.swing.JLabel();
        txtMinuto = new javax.swing.JLabel();
        txtSegundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtHora.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        txtHora.setText("00");

        txtMinuto.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        txtMinuto.setText("00");

        txtSegundo.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        txtSegundo.setText("00");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(93, 93, 93)
                .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtSegundo, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(80, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtSegundo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMinuto, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtHora, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(100, 100, 100))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    public static void main(String args[]) {

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reloj().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel txtHora;
    private javax.swing.JLabel txtMinuto;
    private javax.swing.JLabel txtSegundo;
    // End of variables declaration//GEN-END:variables
 
 public void run() {
        try {
            while (true) {
                segundos++;
                if (segundos == 60) {
                    segundos = 0;
                    minutos++;
                    if (minutos == 60) {
                        minutos = 0;
                        horas++;
                        if (horas == 12) {
                            horas = 0;
                        }
                        actualizarHoras();
                    }
                    actualizarMinutos();
                }
                actualizarSegundos();
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            // Manejo de excepciones
        }
    }
/**
 * Actualiza el texto en la etiqueta txtHora con las horas actuales en un 
 * formato de dos dígitos (agregando un cero al principio si es necesario).
 */
    private void actualizarHoras() {
        txtHora.setText(String.format("%02d", horas));
    }

    /**
     * Actualiza el texto en la etiqueta txtMinuto
     * con los minutos actuales en un formato de dos dígitos.
     */
    private void actualizarMinutos() {
        txtMinuto.setText(String.format("%02d", minutos));
    }
/**
 * Actualiza el texto en la etiqueta txtSegundo
 * con los segundos actuales en un formato de dos dígitos.
 */
    private void actualizarSegundos() {
        txtSegundo.setText(String.format("%02d", segundos));
    }
    
}
