package hilos;

/**
 *
 * @author labtecweb13
 */
public class Hilo1 extends Thread {

    public static void main(String[] args) {
        HiloMostrarCero h1 = new HiloMostrarCero();
        h1.start();
        try {
            h1.sleep(2000);
        } catch (Exception e) {
    }
        HiloMostrarUno h2 = new HiloMostrarUno();
        try {
            h2.sleep(6000);
        } catch (Exception e) {
    }
        h2.start();
    }
}

class HiloMostrarCero extends Thread {

    @Override
    public void run() {
        for (int i = 1; i <= 10; i++) {
            System.out.print("0-");
        }
        System.out.println("");

    }
}

class HiloMostrarUno extends Thread {

    @Override
    public void run() {
        for (int j = 1; j <= 10; j++) {
            System.out.print("1-");
        }
    }
}
