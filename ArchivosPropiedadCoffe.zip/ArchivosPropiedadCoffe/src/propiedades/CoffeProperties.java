package propiedades;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;


/**
 *
 * @author gonzalo
 */
public class CoffeProperties extends javax.swing.JFrame {

    private Properties properties;

    /**
     * Creates new form CoffeProperties
     */
    public CoffeProperties() throws IOException {
        initComponents();
        Properties properties = cargarPropiedades();
    }

    private Properties cargarPropiedades() throws IOException {
        File file = new File("config.properties");
        Properties properties = new Properties();

        if (file.exists()) {
            try (FileReader reader = new FileReader(file)) {
                properties.load(reader);
            }
        } else {
            try (FileWriter writer = new FileWriter(file)) {
                properties.store(writer, "MagiCoffe");
            }
        }

        return properties;
    }

    private void guardarPropiedades() throws IOException {
        try (FileWriter writer = new FileWriter("config.properties")) {
            properties.store(writer, "MagiCoffe");
        }
    }

   private void agregarPropiedades() {
        // Verificar si properties es nulo
        if (properties == null) {
            // Si es nulo, cargar las propiedades nuevamente
            try {
                properties = cargarPropiedades();
            } catch (IOException ex) {
                
            }
        }

        String nombre = JFNombre.getText();
        String clave = JFClave.getText();
        String direccion = JFDireeccion.getText();
        String telefono = JFTelefono.getText();

        properties.setProperty("Nombre", nombre);
        properties.setProperty("Clave", clave);
        properties.setProperty("Direccion", direccion);
        properties.setProperty("Telefono", telefono);

        try {
            guardarPropiedades();
        } catch (IOException ex) {
            
            // Manejar la excepción, por ejemplo, mostrar un mensaje al usuario
        }
    }


   private void mostrarPropiedades() {
    // Verificar si properties es nulo
    if (properties == null) {
        // Si es nulo, cargar las propiedades nuevamente
        try {
            properties = cargarPropiedades();
        } catch (IOException ex) {
           
        }
    }

    // Obtener los valores de las propiedades
    String nombre = properties.getProperty("Nombre", "");
    String clave = properties.getProperty("Clave", "");
    String direccion = properties.getProperty("Direccion", "");
    String telefono = properties.getProperty("Telefono", "");

    // Mostrar los valores en los JTextField
    JFNombre.setText(nombre);
    JFClave.setText(clave);
    JFDireeccion.setText(direccion);
    JFTelefono.setText(telefono);
}
   
   
   
   private void actualizarDatosEnArchivo() {
    // Verificar si properties es nulo
    if (properties == null) {
        // Si es nulo, cargar las propiedades nuevamente
        try {
            properties = cargarPropiedades();
        } catch (IOException ex) {
          
        }
    }

    // Obtener los valores ingresados en los JTextField
    String nombre = JFNombre.getText();
    String clave = JFClave.getText();
    String direccion = JFDireeccion.getText();
    String telefono = JFTelefono.getText();

    // Actualizar las propiedades en el objeto Properties
    properties.setProperty("Nombre", nombre);
    properties.setProperty("Clave", clave);
    properties.setProperty("Direccion", direccion);
    properties.setProperty("Telefono", telefono);

    // Guardar las propiedades en el archivo config.properties
    try {
        guardarPropiedades();
    } catch (IOException ex) {
       
    }
}

   
   
   
   
   
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNombre = new javax.swing.JLabel();
        txtClave = new javax.swing.JLabel();
        txtDireccion = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        JFNombre = new javax.swing.JTextField();
        JFClave = new javax.swing.JTextField();
        JFDireeccion = new javax.swing.JTextField();
        JFTelefono = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        btnActualizar = new javax.swing.JButton();
        btnMostrar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtNombre.setText("Nombre :");

        txtClave.setText("Clave:");

        txtDireccion.setText("Dirección:");

        jLabel1.setText("Telefono:");

        JFNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFNombreActionPerformed(evt);
            }
        });

        JFDireeccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFDireeccionActionPerformed(evt);
            }
        });

        JFTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                JFTelefonoActionPerformed(evt);
            }
        });

        btnAgregar.setText("Agregar");
        btnAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgregarActionPerformed(evt);
            }
        });

        btnActualizar.setText("Actualizar");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnMostrar.setText("Mostrar Datos");
        btnMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMostrarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAgregar)
                        .addGap(28, 28, 28)
                        .addComponent(btnActualizar)
                        .addGap(18, 18, 18)
                        .addComponent(btnMostrar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnEliminar))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(JFTelefono, javax.swing.GroupLayout.DEFAULT_SIZE, 315, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(txtDireccion)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(JFDireeccion))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtNombre)
                                .addComponent(txtClave))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(JFNombre)
                                .addComponent(JFClave, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)))))
                .addContainerGap(74, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(77, 77, 77)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtNombre)
                    .addComponent(JFNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtClave)
                    .addComponent(JFClave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDireccion)
                    .addComponent(JFDireeccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JFTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAgregar)
                    .addComponent(btnActualizar)
                    .addComponent(btnMostrar)
                    .addComponent(btnEliminar))
                .addContainerGap(102, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void JFNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JFNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JFNombreActionPerformed

    private void JFDireeccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JFDireeccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JFDireeccionActionPerformed

    private void JFTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_JFTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_JFTelefonoActionPerformed

    private void btnAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgregarActionPerformed
        // TODO add your handling code here:
        agregarPropiedades();
        
    }//GEN-LAST:event_btnAgregarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
          actualizarDatosEnArchivo();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMostrarActionPerformed
        // TODO add your handling code here:
        mostrarPropiedades();
    }//GEN-LAST:event_btnMostrarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEliminarActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new CoffeProperties().setVisible(true);
                } catch (IOException ex) {
                    //Logger.getLogger(CoffeProperties.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField JFClave;
    private javax.swing.JTextField JFDireeccion;
    private javax.swing.JTextField JFNombre;
    private javax.swing.JTextField JFTelefono;
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMostrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel txtClave;
    private javax.swing.JLabel txtDireccion;
    private javax.swing.JLabel txtNombre;
    // End of variables declaration//GEN-END:variables
}


