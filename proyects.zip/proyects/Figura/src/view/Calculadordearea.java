/* *************************************
 * Autor:  José Ángel Márquez Espina   *
 * Creado: 03/10/2023                  *
 * Modificado: 03/10/2023              *
 * Descripciòn:Interfaz del            *
 *             calculadordearea        *
 ***************************************/
package view;

import entity.Cuadrado;
import entity.rectangulo;
import javax.swing.JOptionPane;

public class Calculadordearea extends javax.swing.JFrame {

    public Calculadordearea() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        RadioButtonCuadrado = new javax.swing.JRadioButton();
        RadioButtonRectangulo = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        TextFieldlado = new javax.swing.JTextField();
        ButtonArea = new javax.swing.JButton();
        Calculararea = new javax.swing.JTextField();
        TextFieldaltura = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Seleccione una opcion:");

        buttonGroup1.add(RadioButtonCuadrado);
        RadioButtonCuadrado.setText("Cuadrado");

        buttonGroup1.add(RadioButtonRectangulo);
        RadioButtonRectangulo.setText("Rectàngulo");

        jLabel2.setText("valor del lado:");

        ButtonArea.setText("CalcularArea");
        ButtonArea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ButtonAreaActionPerformed(evt);
            }
        });

        jLabel3.setText("Valor de la altura:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TextFieldaltura)
                            .addComponent(ButtonArea, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TextFieldlado)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Calculararea, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(RadioButtonCuadrado)
                                .addGap(64, 64, 64)
                                .addComponent(RadioButtonRectangulo)))))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RadioButtonCuadrado)
                    .addComponent(RadioButtonRectangulo))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(TextFieldlado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TextFieldaltura, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ButtonArea)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addComponent(Calculararea, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Botòn para calculalr el àrea de la figura seleccionada
    private void ButtonAreaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ButtonAreaActionPerformed
         if (RadioButtonCuadrado.isSelected()) {
             
            try {
                double lado = Double.parseDouble(TextFieldlado.getText());
                Cuadrado cuadrado = new Cuadrado(lado);
                double area = cuadrado.calcularArea();
                Calculararea.setText("El Área del Cuadrado: " + area);
              
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                        "Ingrese un valor válido para el lado.", 
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
             if (!TextFieldaltura.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                    "Se ha ingresado un valor en el campo de altura."
                            + " Solo se usará el valor del lado.", 
                    "Advertencia", JOptionPane.ERROR_MESSAGE);
            }
            
        } else if (RadioButtonRectangulo.isSelected()) {
            try {
                double base = Double.parseDouble(TextFieldlado.getText());
                double altura = Double.parseDouble(TextFieldaltura.getText()); 
                rectangulo rectangulo = new rectangulo(base, altura);
                double area = rectangulo.calcularArea();
                Calculararea.setText("El Área del Rectángulo: " + area);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, 
                        "Ingrese valores válidos para base y la altura.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
         
        } else {
            JOptionPane.showMessageDialog(this, 
                    "Seleccione una opción.", "Error", 
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_ButtonAreaActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Calculadordearea().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton ButtonArea;
    private javax.swing.JTextField Calculararea;
    private javax.swing.JRadioButton RadioButtonCuadrado;
    private javax.swing.JRadioButton RadioButtonRectangulo;
    private javax.swing.JTextField TextFieldaltura;
    private javax.swing.JTextField TextFieldlado;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
