/* *************************************
 * Autor:  José Ángel Márquez Espina   *
 * Creado: 03/10/2023                  *
 * Modificado: 03/10/2023              *
 * Descripciòn:Clase Figura            *
 ***************************************/
package entity;

public abstract class Figura {
    public abstract double calcularArea();
}