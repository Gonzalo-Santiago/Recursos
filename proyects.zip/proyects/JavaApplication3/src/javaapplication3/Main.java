
package javaapplication3;

/**
 *
 * @author labtecweb13
 */
public class Main {
    public static void main(String[] args) {
        
        Externa ex= new Externa();
            ex.proceso();
    }
    
}
