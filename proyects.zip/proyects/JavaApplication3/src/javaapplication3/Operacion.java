
package javaapplication3;

/**
 *
 * @author labtecweb13
 */
public class Operacion {
    
    public  void imprimir(){
        System.out.println("impresion de operaciones");
    }
}
