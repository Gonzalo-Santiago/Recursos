/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication3;

/**
 *
 * @author labtecweb13
 */
public class Externa {
    Operacion op= new Operacion(){
        //
        public  void imprimir(){
            
            System.out.println("impresion anonima");
        }
    };
    
    void proceso(){
        op.imprimir();
    }
}
