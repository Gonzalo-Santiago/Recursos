/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package java2;

/**
 *
 * @author labtecweb13
 */
public class Externa {
    Runnable rn= new Runnable() {
        @Override
        public void run() {
            System.out.println("RUN ANONIMO");
        }
    };
    
}
