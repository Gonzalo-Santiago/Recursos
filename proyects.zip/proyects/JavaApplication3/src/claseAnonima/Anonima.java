
package claseAnonima;

/**
 *
 * @author labtecweb13
 */
public class Anonima {

    public Anonima() {}
    
    public void inicializar(){
         Saludar obj= new Saludar(){
             public void Saludar(){
                 System.out.println("hola 506 anonima");
             }
         };
    }
    
}

interface Saludar{
    public void Saludar();
}

class Main {
    public static void main(String[] args) {
        Anonima a= new Anonima();
       a.inicializar();
    }
    
}
