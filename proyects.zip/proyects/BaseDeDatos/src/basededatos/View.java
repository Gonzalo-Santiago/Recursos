package basededatos;

import java.sql.*;
import javax.swing.JOptionPane;

public class View extends javax.swing.JFrame {

    private String nombreBaseDatos;

    public View() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        crearbd = new javax.swing.JButton();
        crearTabla = new javax.swing.JButton();
        insertar = new javax.swing.JButton();
        consultal = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        crearbd.setText("Crear BD");
        crearbd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crearbdMouseClicked(evt);
            }
        });
        crearbd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crearbdActionPerformed(evt);
            }
        });

        crearTabla.setText("Crear Tabla");
        crearTabla.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                crearTablaMouseClicked(evt);
            }
        });
        crearTabla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crearTablaActionPerformed(evt);
            }
        });

        insertar.setText("Insertar");
        insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertarActionPerformed(evt);
            }
        });

        consultal.setText("Consultar");

        jButton3.setText("Eliminar BD");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(crearbd)
                        .addGap(165, 165, 165)
                        .addComponent(crearTabla))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addComponent(insertar)
                        .addGap(37, 37, 37)
                        .addComponent(consultal)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton3)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(crearbd)
                    .addComponent(crearTabla))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(insertar)
                            .addComponent(consultal))
                        .addGap(41, 41, 41))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(33, 33, 33))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void crearbdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crearbdActionPerformed

    }//GEN-LAST:event_crearbdActionPerformed

    
    private void crearTablaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crearTablaActionPerformed

    }//GEN-LAST:event_crearTablaActionPerformed

    private void insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertarActionPerformed
      //boton insertat datos
        
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+nombreBaseDatos, "postgres", "gonzalo");
            Statement s = con.createStatement();

            String tableName = "506"; // Nombre de la tabla

            // Solicitar al usuario que ingrese los valores de los campos
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre:");
            String matriculaStr = JOptionPane.showInputDialog("Ingrese la matrícula:");
            int matricula = Integer.parseInt(matriculaStr);
            String carrera = JOptionPane.showInputDialog("Ingrese la carrera:");

            // Crear la sentencia SQL para insertar datos en la tabla
            String insertSQL = "INSERT INTO \"" + tableName + "\" (nombre, matricula, carrera) VALUES "
                    + "('" + nombre + "', " + matricula + ", '" + carrera + "');";

            // Ejecutar la sentencia SQL para insertar datos
            s.executeUpdate(insertSQL);

            insertar.setEnabled(false);
            JOptionPane.showMessageDialog(null, "Datos insertados correctamente");

            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_insertarActionPerformed

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked

        String nombreBaseDatos = JOptionPane.showInputDialog(null, "Ingrese el nombre de la base de datos a eliminar:");

        if (nombreBaseDatos != null && !nombreBaseDatos.isEmpty()) {
            try {
                Class.forName("org.postgresql.Driver");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "gonzalo");
                Statement s = con.createStatement();

                // Eliminar la base de datos
                int rs = s.executeUpdate("DROP DATABASE IF EXISTS " + nombreBaseDatos + ";");

                if (rs >= 0) {
                    // Mostrar mensaje de éxito
                    JOptionPane.showMessageDialog(null, "La base de datos " + nombreBaseDatos + " se ha eliminado con éxito.");
                } else {
                    // La base de datos no se encontró o no se pudo eliminar
                    JOptionPane.showMessageDialog(null, "La base de datos " + nombreBaseDatos + " no se pudo eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                // Manejar errores aquí si es necesario
                JOptionPane.showMessageDialog(null, "Error al eliminar la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // El usuario canceló la entrada del nombre de la base de datos o no ingresó un nombre.
            JOptionPane.showMessageDialog(null, "No se proporcionó un nombre de base de datos a eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Preguntar al usuario el nombre de la base de datos
        String nombreBaseDatos = JOptionPane.showInputDialog(null, "Ingrese el nombre de la base de datos a eliminar:");

        if (nombreBaseDatos != null && !nombreBaseDatos.isEmpty()) {
            try {
                Class.forName("org.postgresql.Driver");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "gonzalo");
                Statement s = con.createStatement();

                // Eliminar la base de datos
                int rs = s.executeUpdate("DROP DATABASE IF EXISTS " + nombreBaseDatos + ";");

                if (rs >= 0) {
                    // Mostrar mensaje de éxito
                    JOptionPane.showMessageDialog(null, "La base de datos " + nombreBaseDatos + " se ha eliminado con éxito.");
                } else {
                    // La base de datos no se encontró o no se pudo eliminar
                    JOptionPane.showMessageDialog(null, "La base de datos " + nombreBaseDatos + " no se pudo eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
                // Manejar errores aquí si es necesario
                JOptionPane.showMessageDialog(null, "Error al eliminar la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // El usuario canceló la entrada del nombre de la base de datos o no ingresó un nombre.
            JOptionPane.showMessageDialog(null, "No se proporcionó un nombre de base de datos a eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void crearTablaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crearTablaMouseClicked

        // Boton crear tablas
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/" + nombreBaseDatos + ";", "postgres", "gonzalo");
            Statement s = con.createStatement();

            //int rs = s.executeUpdate("CREATE DATABASE" + nombreBaseDatos + ";");
            String tableName = "506"; // Nombre de la tabla
            String createTableSQL = "CREATE TABLE \"506\" (id serial PRIMARY KEY, nombre text, matricula int, carrera text);";
            s.executeUpdate(createTableSQL);

            crearTabla.setEnabled(false);
            JOptionPane.showMessageDialog(null, "Tabla creada correctamente");

            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }//GEN-LAST:event_crearTablaMouseClicked

    private void crearbdMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_crearbdMouseClicked
        
        

        // Preguntar al usuario el nombre de la base de datos
        nombreBaseDatos = JOptionPane.showInputDialog(nombreBaseDatos, "Ingrese el nombre de la base de datos:");

        if (nombreBaseDatos != null && !nombreBaseDatos.isEmpty()) {
            try {
                Class.forName("org.postgresql.Driver");
                Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/", "postgres", "gonzalo");
                Statement s = con.createStatement();

                // Crear la base de datos
                int rs = s.executeUpdate("CREATE DATABASE " + nombreBaseDatos + ";");
                // Deshabilitar el botón jButton1
                crearbd.setEnabled(false);
                // Mostrar mensaje de éxito
                JOptionPane.showMessageDialog(null, "La base de datos " + nombreBaseDatos + " se ha creado con éxito.");

            } catch (Exception e) {
                System.out.println(e.getMessage());
                // Manejar errores aquí si es necesario
                JOptionPane.showMessageDialog(null, "Error al crear la base de datos: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // El usuario canceló la entrada de nombre de la base de datos o no ingresó un nombre.
            JOptionPane.showMessageDialog(null, "No se proporcionó un nombre de base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        

        // TODO add your handling code here:
    }//GEN-LAST:event_crearbdMouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new View().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton consultal;
    private javax.swing.JButton crearTabla;
    private javax.swing.JButton crearbd;
    private javax.swing.JButton insertar;
    private javax.swing.JButton jButton3;
    // End of variables declaration//GEN-END:variables
}
