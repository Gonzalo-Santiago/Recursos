package prueba;

import java.sql.*;
import javax.swing.JOptionPane;


public class Prueba1Conexion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Prueba1","postgres","gonza100");
            Statement s = con.createStatement();
            
            // Creacion de la base de datos Prueba1
//            int rs = s.executeUpdate("CREATE DATABASE Prueba1;");
//            String createTableSQL = "CREATE TABLE \"506\" (id serial PRIMARY KEY, nombre text, matricula int, carrera text);";
//            s.executeUpdate(createTableSQL);
//            
            String tableName = "506"; // Nombre de la tabla
            
            // Solicitar al usuario que ingrese los valores de los campos
            String nombre = JOptionPane.showInputDialog("Ingrese el nombre:");
            String matriculaStr = JOptionPane.showInputDialog("Ingrese la matrícula:");
            int matricula = Integer.parseInt(matriculaStr);
            String carrera = JOptionPane.showInputDialog("Ingrese la carrera:");

            // Crear la sentencia SQL para insertar datos en la tabla
            String insertSQL = "INSERT INTO \"" + tableName + "\" (nombre, matricula, carrera) VALUES "
                    + "('" + nombre + "', " + matricula + ", '" + carrera + "');";

            
            
                    
            // Ejecutar la sentencia SQL para insertar datos
            s.executeUpdate(insertSQL);

            JOptionPane.showMessageDialog(null, "Datos insertados correctamente");
            
            
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
}