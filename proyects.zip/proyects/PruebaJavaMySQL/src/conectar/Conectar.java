package conectar;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
    Autor: Xamus Dyson
    Descripción: Clase para gestionar la conexión.
    Sitio: https://www.cablenaranja.com
 */
public class Conectar {
    private static final String URL = "jdbc:mysql://localhost:3306/prueba2";
    private static final String usuario = "postgres";
    private static final String pasword = "gonzalo";
    public Connection getConexion(){
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection(URL, usuario, pasword);
        }catch(ClassNotFoundException | SQLException e){
            System.out.println("Error :" + e.getMessage());
        }
        return con;
    }
}
