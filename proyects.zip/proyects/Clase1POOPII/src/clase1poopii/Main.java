
package clase1poopii;

/**
 *
 * @author labtecweb13
 */
public class Main {
    
    public static void main(String[] args) {
        Externa ex=new Externa();
        Externa.Interna in=ex.new Interna();
        in.mensaje();
    }
    
}
