
package clase1poopii;

/**
 *
 * @author labtecweb13
 */
public class Externa {
    class Interna{
        //String msj="Mensaje externo";
        public void proceso(){
            public void imprime(){
                
            
            
            System.out.println("hola 506 soy la clase internaE /");
        }

    }
    
}

}

