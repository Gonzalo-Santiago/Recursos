
package clase1poopii;

/**
 *
 * @author labtecweb13
 */
public class Interna {
    Interna in = new Interna();
    in.imprime();

}

