
package class2;

/**
 *
 * @author labtecweb13
 */
public class Figura {
    
    public static void CalcularArea() {
        
        CalcularArea();
        System.out.println("area");
    }
    
}
