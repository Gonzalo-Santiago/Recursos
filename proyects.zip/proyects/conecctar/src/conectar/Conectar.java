package conectar;

import java.sql.Connection; // Importación de clases necesarias para trabajar con JDBC (Java Database Connectivity).
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Conectar { // Declaración de la clase Conectar.

    public static Connection c;             // Declaración de una variable estática para la conexión a la base de datos.
    public static Connection server_con;        // Declaración de una variable estática para la conexión al servidor.
    public static String MENSAJE = "";       // Declaración de una variable estática para mensajes de error.
    private String host = "postgres";       // Declaración de una variable para el nombre del servidor.
    private String bdNombre = "prueba2";             // Declaración de una variable para el nombre de la base de datos.
    private String passwd = "gonzalo";       // Declaración de una variable para la contraseña de la base de datos.

    // Método principal (main) de la clase.
    public static void main(String[] args) {
       
    }

    // Método para conectar al servidor de base de datos.
    public Connection conectaServidor() {
        try {
            MENSAJE = "";
            String url = "jdbc:postgresql://" + host; // Construye la URL de conexión al servidor.
            Class.forName("org.postgresql.Driver"); // Carga el controlador de PostgreSQL.
            server_con = DriverManager.getConnection(url, "postgres", passwd); // Establece la conexión al servidor.
        } catch (Exception ex) {
            MENSAJE = ex.getMessage(); // Captura cualquier excepción y almacena el mensaje de error.
        }
        return server_con; // Devuelve la conexión al servidor.
    }

    // Método para crear una base de datos.
    public void creaBD(String stm) {
        try {
            MENSAJE = "";
            Connection c2 = server_con; // Obtiene la conexión al servidor.
            Statement s = c2.createStatement(); // Crea un objeto Statement para ejecutar comandos SQL.
            s.executeUpdate(stm); // Ejecuta el comando SQL para crear la base de datos.
            c2.close(); // Cierra la conexión al servidor.
        } catch (Exception ex) {
            MENSAJE = ex.getMessage(); // Captura cualquier excepción y almacena el mensaje de error.
        }
    }

    // Método para conectar a una base de datos específica.
    public Connection conectaBD() {
        String url = "jdbc:postgresql://" + host + "/" + bdNombre; // Construye la URL de conexión a la base de datos.
        MENSAJE = "";
        try {
            Class.forName("org.postgresql.Driver"); // Carga el controlador de PostgreSQL.
            c = DriverManager.getConnection(url, "postgres", passwd); // Establece la conexión a la base de datos.
        } catch (Exception ex) {
            MENSAJE = ex.getMessage(); // Captura cualquier excepción y almacena el mensaje de error.
        }
        return c; // Devuelve la conexión a la base de datos.
    }

    // Método para realizar una consulta a la base de datos y obtener un ResultSet.
    public ResultSet consulta(String consul) {
        ResultSet r = null; // Declaración de un objeto ResultSet para almacenar los resultados de la consulta.
        MENSAJE = "";
        try {
            Statement stm = c.createStatement(); // Crea un objeto Statement para ejecutar la consulta.
            r = stm.executeQuery(consul); // Ejecuta la consulta y almacena los resultados en el ResultSet.
        } catch (SQLException e) {
            MENSAJE = e.getMessage(); // Captura cualquier excepción de SQL y almacena el mensaje de error.
        }
        return r; // Devuelve el ResultSet con los resultados de la consulta.
    }

    // Método para ejecutar comandos SQL que no devuelven un resultado.
    public void ejecutar(String stm) {
        try {
            MENSAJE = "";
            Statement s = c.createStatement(); // Crea un objeto Statement para ejecutar comandos SQL.
            s.executeUpdate(stm); // Ejecuta el comando SQL.
        } catch (Exception e) {
            MENSAJE = e.getMessage(); // Captura cualquier excepción y almacena el mensaje de error.
        }
    }
}
    

   

