/** **********************************************
 * Autores: Cristopher Alexis Zarate Valencia  *
 * Fecha de creación: 29 oct. 2023                *
 * Descripción: Clase para cambiar de panel.
 *********************************************** */
package controller;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JPanel;

public class ChangePanelController {
    private ArrayList<Integer> listIndex;
    private HashMap<Integer, JPanel> listPanels;
    private JPanel padre;

    public ChangePanelController(JPanel padre) {
        this.listPanels = new HashMap<>();
        this.listIndex = new ArrayList<>();
        this.padre = padre;
    }

    public void setPadre(JPanel padre) {
        this.padre = padre;
    }
    
    public void addPanel( JPanel pnl) {
        listPanels.put(genIndex(), pnl);
    }
    
    public void changePanel(int index){
        if(padre.getComponents().length>0)
            padre.removeAll();
        
        padre.add(listPanels.get(index));
        padre.repaint();
    }
    
    private int genIndex(){    
        int lastIndex = listIndex.size();
        listIndex.add(lastIndex+1);
        return listIndex.size();
    }
}
