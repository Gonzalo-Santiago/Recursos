/** **********************************************
 * Autores: Cristopher Alexis Zarate Valencia  *
 * Fecha de creación: 30 oct. 2023                *
 * Descripción: Clase para abrir cuadros de dialogo.
 *********************************************** */

package controller;

import javax.swing.JDialog;
import javax.swing.JFrame;


public class OpenDialogController {
    private JFrame padre;

    public OpenDialogController(JFrame padre) {
        this.padre = padre;
    }
    
    private void openDialog(JDialog cuadro){
        cuadro = new JDialog();
        
    }
}
