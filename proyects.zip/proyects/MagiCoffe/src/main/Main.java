package main;

import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.extras.FlatInspector;
import view.LoginFrame;
import view.PrincipalFrame;

public class Main {
/*
    public static void main(String args[]) {

        try {

            // Asigno el tema con un UI manager.
            FlatLaf.registerCustomDefaultsSource("style");
//            UIManager.setLookAndFeel(new FlatGrayIJTheme());
            FlatLightLaf.setup();
//            LoginFrame.setDefaultLookAndFeelDecorated(
//                    true);
        } catch (Exception ex) {
            System.err.println("Failed to initialize FlatLaf");
        }

        // Personalizo los componentes.
//        FlatLafCoustom.inizializedCoustom();
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginFrame().setVisible(true);
            }
        });
    }
    */
}
