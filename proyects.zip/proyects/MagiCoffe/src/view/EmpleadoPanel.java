/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package view;

import javax.swing.JFrame;

/**
 *
 * @author labtecweb05
 */
public class EmpleadoPanel extends javax.swing.JPanel {

    /**
     * Creates new form AgregarEmpleado
     */
    EmpleadoPanel() {
        initComponents();
    }

//    public static void main(String[] args) {
//        JFrame frame = new JFrame("Empleado");
//        EmpleadoPanel panel = new EmpleadoPanel();
//        frame.add(panel);
//
//        //frame.setSize(1440, 824);
//        frame.setVisible(true);
//    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbTablaEmpleados = new javax.swing.JTable();
        lbEmpleados = new javax.swing.JLabel();
        btnAñadirEmpleado = new javax.swing.JButton();
        btnImprimir = new javax.swing.JButton();
        btnBuscar = new javax.swing.JButton();
        lbRegistro = new javax.swing.JLabel();

        tbTablaEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre y apellidos", "Estado", "Sucursal", "Cargo", "Salario", "Acciones Rapidas"
            }
        ));
        jScrollPane1.setViewportView(tbTablaEmpleados);

        lbEmpleados.setFont(new java.awt.Font("Liberation Sans", 0, 14)); // NOI18N
        lbEmpleados.setText("Empleados");

        btnAñadirEmpleado.setText("Añadir Empleado");

        btnImprimir.setText("Imprimir");

        btnBuscar.setText("Buscar");

        lbRegistro.setText("Registros:      ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbEmpleados)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnAñadirEmpleado)
                        .addGap(30, 30, 30)
                        .addComponent(lbRegistro)
                        .addGap(18, 18, 18)
                        .addComponent(btnImprimir)
                        .addGap(18, 18, 18)
                        .addComponent(btnBuscar))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 977, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbEmpleados)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAñadirEmpleado)
                    .addComponent(lbRegistro)
                    .addComponent(btnImprimir)
                    .addComponent(btnBuscar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAñadirEmpleado;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnImprimir;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbEmpleados;
    private javax.swing.JLabel lbRegistro;
    private javax.swing.JTable tbTablaEmpleados;
    // End of variables declaration//GEN-END:variables
}
