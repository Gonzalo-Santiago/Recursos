package view;

import javax.swing.JPanel;


public class AgregarProductoPanel extends javax.swing.JPanel {

    /**
     * Creates new form pnlAgregarProducto
     */
    public AgregarProductoPanel() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        txtBarraSuperiorAgregarProducto = new javax.swing.JTextField();
        lbNuevoProducto = new javax.swing.JLabel();
        lbCodigoBarras = new javax.swing.JLabel();
        lbNombreNuevoProducto = new javax.swing.JLabel();
        txtCodigoBarras = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        lbTipo = new javax.swing.JLabel();
        rbtnComida = new javax.swing.JRadioButton();
        rbtnIngrediente = new javax.swing.JRadioButton();
        rbtnProducto = new javax.swing.JRadioButton();

        setMaximumSize(new java.awt.Dimension(1440, 824));
        setMinimumSize(new java.awt.Dimension(1440, 824));
        setName(""); // NOI18N

        txtBarraSuperiorAgregarProducto.setBackground(new java.awt.Color(102, 102, 102));
        txtBarraSuperiorAgregarProducto.setText("jTextField1");

        lbNuevoProducto.setFont(new java.awt.Font("Liberation Sans", 0, 30)); // NOI18N
        lbNuevoProducto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbNuevoProducto.setText("Nuevo producto");

        lbCodigoBarras.setFont(new java.awt.Font("Liberation Sans", 0, 18)); // NOI18N
        lbCodigoBarras.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbCodigoBarras.setText("Código de barras");

        lbNombreNuevoProducto.setFont(new java.awt.Font("Liberation Sans", 0, 18)); // NOI18N
        lbNombreNuevoProducto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbNombreNuevoProducto.setText("Nombre");

        lbTipo.setFont(new java.awt.Font("Liberation Sans", 0, 18)); // NOI18N
        lbTipo.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lbTipo.setText("Tipo");

        buttonGroup1.add(rbtnComida);
        rbtnComida.setText("Comida");
        rbtnComida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnComidaActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtnIngrediente);
        rbtnIngrediente.setText("Ingrediente");

        buttonGroup1.add(rbtnProducto);
        rbtnProducto.setText("Producto");
        rbtnProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnProductoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(txtBarraSuperiorAgregarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 1440, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbNuevoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbCodigoBarras, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(txtCodigoBarras, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbNombreNuevoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(rbtnComida)
                        .addGap(76, 76, 76)
                        .addComponent(rbtnIngrediente)
                        .addGap(55, 55, 55)
                        .addComponent(rbtnProducto))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(txtBarraSuperiorAgregarProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 6, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(lbNuevoProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(lbCodigoBarras))
                    .addComponent(txtCodigoBarras, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(lbNombreNuevoProducto))
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(lbTipo))
                    .addComponent(rbtnComida, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbtnIngrediente, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rbtnProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void rbtnComidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnComidaActionPerformed
        ComidaPanel panelComida= new ComidaPanel();
        panelComida.setVisible(true);
        panelComida.setLocation(420,30);
    }//GEN-LAST:event_rbtnComidaActionPerformed

    private void rbtnProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnProductoActionPerformed
        ProductoPanel panelProducto= new ProductoPanel();
        panelProducto.setVisible(true);
        panelProducto.setLocation(420,30);
    }//GEN-LAST:event_rbtnProductoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel lbCodigoBarras;
    private javax.swing.JLabel lbNombreNuevoProducto;
    private javax.swing.JLabel lbNuevoProducto;
    private javax.swing.JLabel lbTipo;
    private javax.swing.JRadioButton rbtnComida;
    private javax.swing.JRadioButton rbtnIngrediente;
    private javax.swing.JRadioButton rbtnProducto;
    private javax.swing.JTextField txtBarraSuperiorAgregarProducto;
    private javax.swing.JTextField txtCodigoBarras;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
