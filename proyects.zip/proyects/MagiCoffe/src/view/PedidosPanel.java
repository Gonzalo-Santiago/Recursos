package view;

import javax.swing.JFrame;



/**
 *
 * @author labtecweb13
 */
public class PedidosPanel extends javax.swing.JPanel {


    public PedidosPanel() {
        initComponents();
        
      
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tbPedidos = new javax.swing.JTable();

        tbPedidos.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        tbPedidos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "FOLIO", "NOMBRE DE LOS PRODUCTOS", "CANTIDAD"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbPedidos.setRowHeight(155);
        jScrollPane2.setViewportView(tbPedidos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 1054, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    /*
    public static void main(String[] args) {
        JFrame frame = new JFrame("Mi Aplicación con Panel");
PedidosPanel panel = new PedidosPanel();
frame.add(panel);
	
   
frame.setSize(1440, 824);
frame.setVisible(true);

    }*/

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tbPedidos;
    // End of variables declaration//GEN-END:variables
}
