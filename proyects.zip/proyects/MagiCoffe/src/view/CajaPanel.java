
package view;

import javax.swing.JFrame;

/**
 *
 * @author labtecweb13
 */
public class CajaPanel extends javax.swing.JPanel {

    public CajaPanel() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbFolio = new javax.swing.JTable();
        lbNumFolio = new javax.swing.JLabel();
        lbNumCaja = new javax.swing.JLabel();
        lbPedido = new javax.swing.JLabel();
        lbFolio = new javax.swing.JLabel();
        lbCaja = new javax.swing.JLabel();

        tbFolio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                { new Integer(1)},
                { new Integer(222)},
                { new Integer(4515)},
                { new Integer(6)},
                {null}
            },
            new String [] {
                "FOLIO"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tbFolio.setColumnSelectionAllowed(true);
        tbFolio.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbFolio.setDoubleBuffered(true);
        tbFolio.setRowHeight(155);
        tbFolio.setSurrendersFocusOnKeystroke(true);
        jScrollPane1.setViewportView(tbFolio);

        lbNumFolio.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        lbNumFolio.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbNumFolio.setText("0055");

        lbNumCaja.setBackground(new java.awt.Color(0, 204, 204));
        lbNumCaja.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        lbNumCaja.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbNumCaja.setText("caja1");

        lbPedido.setFont(new java.awt.Font("Noto Sans", 0, 48)); // NOI18N
        lbPedido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbPedido.setText("tortas y jugo");

        lbFolio.setFont(new java.awt.Font("Noto Sans", 0, 24)); // NOI18N
        lbFolio.setText("FOLIO");

        lbCaja.setFont(new java.awt.Font("Noto Sans", 0, 24)); // NOI18N
        lbCaja.setText("CAJA");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lbNumFolio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbNumCaja, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(187, 187, 187)
                        .addComponent(lbFolio)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lbCaja)
                        .addGap(278, 278, 278))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lbPedido, javax.swing.GroupLayout.PREFERRED_SIZE, 1124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 699, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbFolio)
                    .addComponent(lbCaja))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbNumCaja, javax.swing.GroupLayout.DEFAULT_SIZE, 361, Short.MAX_VALUE)
                    .addComponent(lbNumFolio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbPedido, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    
    /*
    public static void main(String[] args) {
        JFrame frame = new JFrame("Mi Aplicación con Panel");
CajaPanel panel = new CajaPanel();
frame.add(panel);
	
   
frame.setSize(1440, 824);
frame.setVisible(true);
    }
*/
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbCaja;
    private javax.swing.JLabel lbFolio;
    private javax.swing.JLabel lbNumCaja;
    private javax.swing.JLabel lbNumFolio;
    private javax.swing.JLabel lbPedido;
    private javax.swing.JTable tbFolio;
    // End of variables declaration//GEN-END:variables
}
