/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashSet;
import java.util.Set;
/**
 *
 * @author labtecweb06
 */
public class tbdTablaVentas {
    /*
public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("TabbedPane con Tablas");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // Crea un JTabbedPane
            JTabbedPane tabbedPane = new JTabbedPane();

            // Agrega una pestaña inicial con una tabla
            tabbedPane.addTab("Pestaña 1", createTablePanel(1));

            // Agrega una pestaña especial al final
            tabbedPane.addTab("+", null);

            // Lleva un registro de los nombres de las pestañas existentes
            Set<String> existingTabNames = new HashSet<>();
            existingTabNames.add("Pestaña 1");

            // Agrega un botón para eliminar la pestaña seleccionada
            JButton closeButton = new JButton("Eliminar Pestaña Seleccionada");
            closeButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int selectedTabIndex = tabbedPane.getSelectedIndex();
                    if (selectedTabIndex != -1 && selectedTabIndex < tabbedPane.getTabCount() - 1) {
                        String tabName = tabbedPane.getTitleAt(selectedTabIndex);
                        existingTabNames.remove(tabName); // Elimina el nombre de la pestaña de la lista
                        tabbedPane.remove(selectedTabIndex);
                    }
                }
            });

            // Agrega el botón en una pestaña especial
            tabbedPane.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    int tabIndex = tabbedPane.indexAtLocation(e.getX(), e.getY());
                    if (tabIndex == tabbedPane.getTabCount() - 1) {
                        // Si se hace clic en la pestaña especial, agrega una nueva pestaña con un nombre único
                        String tabName = generateUniqueTabName(existingTabNames);
                        existingTabNames.add(tabName); // Agrega el nombre a la lista
                        int newTabIndex = tabbedPane.getTabCount() - 1;
                        tabbedPane.insertTab(tabName, null, createTablePanel(newTabIndex + 1), null, newTabIndex);
                        tabbedPane.setSelectedIndex(newTabIndex);
                    }
                }
            });

            // Establece la pestaña especial para no ser seleccionable
            tabbedPane.setEnabledAt(tabbedPane.getTabCount() - 1, true);

            // Crea un panel para colocar el botón
            JPanel buttonPanel = new JPanel();
            buttonPanel.add(closeButton);

            // Agrega el JTabbedPane y el panel del botón al JFrame
            frame.add(tabbedPane);
            frame.add(buttonPanel, BorderLayout.SOUTH);

            frame.setSize(600, 400);
            frame.setVisible(true);
        });
    }*/

    private static JScrollPane createTablePanel(int tabNumber) {
        JTable table = new JTable(new DefaultTableModel(10, 2));
        JScrollPane scrollPane = new JScrollPane(table);
        return scrollPane;
    }

    private static String generateUniqueTabName(Set<String> existingNames) {
        int i = 1;
        while (true) {
            String newName = "Pestaña " + i;
            if (!existingNames.contains(newName)) {
                return newName;
            }
            i++;
        }
    }
    
}
