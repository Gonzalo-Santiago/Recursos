/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.BusquedaPanel;

public class btnBuscar extends JButton {
    public btnBuscar() {
        // Configura el texto del botón
        setText("Abrir Diálogo");

        // Agrega un ActionListener al botón
        addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crea un nuevo JDialog
                JDialog dialog = new JDialog();
                dialog.setTitle("Mi Diálogo");

                // Agrega el panel previamente creado (miPanel) al JDialog
                dialog.add(new BusquedaPanel());

                // Configura el tamaño y muestra el diálogo
                dialog.setSize(780, 790);
                dialog.setVisible(true);
            }
        });
    }
}
   