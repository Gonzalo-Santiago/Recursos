# MagiCoffe
Software para la aldministración de un Café / Restaurante.
# Requisitos
- Java: [SE Development Kit 17.0.8](https://download.oracle.com/java/17/archive/jdk-17.0.8_windows-x64_bin.exe "SE Development Kit 17.0.8").
