package prueba;


/**
 *
 * @author labtecweb13
 */

import java.sql.*;
import javax.swing.JOptionPane;


public class Main {
    
    public static void main(String[] args) {
        
    
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:5432/prueba1","postgres","gonzalo");
            Statement s = con.createStatement();
            // int rs = s.executeUpdate("CREATE table usuario (id serial  primary key, nombre varchar(20), matricula varchar(20), carrera varchar(20));");
            
            String nombre = JOptionPane.showInputDialog("INGRESE EL NOMBRE");
            String matriculas = JOptionPane.showInputDialog("INGRESE LA MATRICULA");
            int matricula = Integer.parseInt(matriculas);
            String carrera = JOptionPane.showInputDialog("INGRESE su carrera");
         
            String usuario = "INSERT INTO usuario (nombre, matricula, carrera) "
                    + "VALUES ('" + nombre + "', " + matricula + ", '" + carrera + "');";

            s.executeUpdate(usuario);
        
            String consulta = "SELECT * FROM usuario";
            ResultSet rs = s.executeQuery(consulta);
         
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombreConsulta = rs.getString("nombre");
                String matriculaConsulta = rs.getString("matricula");
                String carreraConsulta = rs.getString("carrera");
                System.out.println("ID: " + id + ", Nombre: " + nombreConsulta + ", Matrícula: " + matriculaConsulta + ", Carrera: " + carreraConsulta);
            }
            
            con.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
      
}
