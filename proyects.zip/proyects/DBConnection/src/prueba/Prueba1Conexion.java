
package prueba;

import java.sql.Connection;
import java.sql.DriverManager;


import java.sql.*;

public class Prueba1Conexion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            Class.forName("org.postgresql.Driver");
            Connection con = DriverManager.getConnection("udbc:postgresql://localhost:5432/","servidorMax","123456789");
            Statement s = con.createStatement();
            int rs = s.executeUpdate("CREATE DATABASE Prueba1:");
            con.close();
        } catch (Exception e) {
            System.out.println("e");
        }
    }
    
}
