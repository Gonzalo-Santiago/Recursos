/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
    import java.util.concurrent.Semaphore;
/**
 *
 * @author labso06
 */
class Barbero {
    

  private Semaphore sillasEspera;
  private Semaphore barberoListo;
  private Semaphore sillaBarbero;

  public Barbero() {
  sillasEspera = new Semaphore(4); // Número de sillas de espera disponibles
  barberoListo = new Semaphore(0); // Indica si el barbero está listo para cortar el pelo
  sillaBarbero = new Semaphore(0); // Indica si hay un cliente en la silla del barbero
  }

  public void cortarPelo() {
  try {
  sillasEspera.acquire(); // El cliente ocupa una silla de espera
  sillaBarbero.release(); // El cliente se sienta en la silla del barbero
  barberoListo.acquire(); // Espera a que el barbero esté listo para cortar el pelo
  sillasEspera.release(); // El cliente deja la silla de espera
  // El barbero corta el pelo
  System.out.println("El barbero está cortando el pelo");
  Thread.sleep(2000); // Simulación del tiempo que tarda en cortar el pelo
  System.out.println("El barbero ha terminado de cortar el pelo");
  } catch (InterruptedException e) {
  e.printStackTrace();
  }
  }

  public void esperarCliente() {
  try {
  while (true) {
  sillaBarbero.acquire(); // Espera a que haya un cliente en la silla del barbero
  barberoListo.release(); // El barbero está listo para cortar el pelo
  // El barbero corta el pelo
  System.out.println("El barbero está cortando el pelo");
  Thread.sleep(2000); // Simulación del tiempo que tarda en cortar el pelo
  System.out.println("El barbero ha terminado de cortar el pelo");
  }
  } catch (InterruptedException e) {
  e.printStackTrace();
  }
  }
}

class Cliente implements Runnable {
  private Barbero barbero;

  public Cliente(Barbero barbero) {
  this.barbero = barbero;
  }

  @Override
  public void run() {
  barbero.cortarPelo();
  }
}

public class Main {
  public static void main(String[] args) {
  Barbero barbero = new Barbero();
  Thread barberoThread = new Thread(() -> barbero.esperarCliente());
  barberoThread.start();

  for (int i = 0; i < 10; i++) {
  Thread clienteThread = new Thread(new Cliente(barbero));
  clienteThread.start();
  }
  }
}
    

