   
import java.sql.*;

/**
 *
 * @author labso06
 */
public class Conectar {
    
   private Connection conexion;
    
    public void crearBd(){
         try {
            Connection conexion=DriverManager.getConnection("jdbc:postgresql://localhost:5432/","postgres","22062003");
            Statement s= conexion.createStatement();
            int rs= s.executeUpdate("CREATE DATABASE bdGonzalo");
            conexion.close();
            
        } catch (Exception e) {
             System.out.println(e);
        }
    }
    
    public void crearTable(String nametable, String tamanioCol){
        
        try {
           Connection conexion=DriverManager.getConnection("jdbc:postgresql://localhost:5432/","postgres","22062003");
            Statement s = conexion.createStatement();
            String sql = "CREATE TABLE " + nametable + " (" + tamanioCol + ")";
            s.executeUpdate(sql);
            conexion.close();
            System.out.println("Tabla creada exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al crear la tabla: " + e.getMessage());
        }
    }
        
    }

