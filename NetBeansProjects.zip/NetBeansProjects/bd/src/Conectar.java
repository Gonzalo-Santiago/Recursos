
import java.sql.*;

/**
 *
 * @author labso06
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Conectar {

    private final String url = "jdbc:postgresql://localhost:5432/";
    private final String usuario = "postgres";
    private final String contrasena = "22062003";
    public static String MENSAJE = "";
    public static Connection c;

    // Método para crear la base de datos
    public void crearBd() {
        Connection conexion = null;
        try {
            // Conectar al servidor de PostgreSQL sin especificar la base de datos
            conexion = DriverManager.getConnection(url, usuario, contrasena);
            Statement s = conexion.createStatement();
            // Crear la base de datos si no existe
            s.executeUpdate("CREATE DATABASE bdgonzalo");
            System.out.println("Base de datos creada exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al crear la base de datos: " + e.getMessage());
        } finally {
            // Cerrar la conexión
            if (conexion != null) {
                try {
                    conexion.close();
                } catch (Exception e) {
                    /* Ignorar error */ }
            }
        }
    }

    // Método para crear una tabla en la base de datos "bdGonzalo"
    public void crearTable(String nombreTabla, String definicionColumnas) {
        Connection conexion = null;
        try {
            // Conectar a la base de datos "bdGonzalo"
            conexion = DriverManager.getConnection(url + "bdgonzalo", usuario, contrasena);
            Statement s = conexion.createStatement();
            // Crear la tabla con el nombre y columnas especificadas
            String sql = "CREATE TABLE " + nombreTabla + " (" + definicionColumnas + ")";
            s.executeUpdate(sql);
            System.out.println("Tabla creada exitosamente.");
        } catch (Exception e) {
            System.out.println("Error al crear la tabla: " + e.getMessage());
        } finally {
            // Cerrar la conexión
            if (conexion != null) {
                try {
                    conexion.close();
                } catch (Exception e) {
                }
            }
        }
    }

    public void ejecutar(String stm) {
        try {
            MENSAJE = "";
            Statement s = c.createStatement();
            System.out.println(stm);
            s.executeUpdate(stm);
        } catch (Exception e) {
            MENSAJE = e.getMessage();
        }
    }

    
    public ResultSet consultar(String query) throws SQLException {
        Statement stmt = c.createStatement();
        return stmt.executeQuery(query);
    }

    public java.sql.ResultSet consulta(String consul) {
        java.sql.ResultSet r = null;
        MENSAJE = "";
        try {
            java.sql.Statement stm = c.createStatement();
            r = stm.executeQuery(consul);
        } catch (SQLException e) {
            MENSAJE = e.getMessage();
        }
        return r;
    }


}

