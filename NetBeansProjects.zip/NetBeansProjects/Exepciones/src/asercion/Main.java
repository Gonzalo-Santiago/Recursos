
package asercion;

/**
 *
 * @author labso06
 */
public class Main {
   
    public static void main(String[] args) {
        
        int x = -15;
        Assertion da = new Assertion();
        assert x > 0 : "El valor debe ser positivo";
        System.out.println("Valor positivo x: " + x);
    }
}


