

package asercion;

/**
 *
 * @author labso06
 */
public class Assertion {
    
    public static void main(String[] args) {
        int num =-8;
        proceso(num);
    }
    
    public static void proceso(int num){
        assert(num>0):num+": no es positivo";
    }
}
