
package exep;

/**
 *
 * @author labso06
 */
public class ExcepcionPersonalizada extends Exception{
   public ExcepcionPersonalizada(String mensaje){
       super(mensaje);
   }

    
}
