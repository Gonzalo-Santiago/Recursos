
package exep.Clase;

import exep.Clase.CMiclase;

/**
 *
 * @author labso06
 */
public class Main {
    public static void main(String[] args) {
        /*
        int x=0;
       public  Miclase(String s){
           try {
               
           } catch (CMiclase e) {
           }
       }
    }*/
}
}