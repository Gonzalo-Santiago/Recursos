
package exep.Clase;

import exep.ExcepcionPersonalizada;

/**
 *
 * @author labso06
 */
public class CMiclase {
    /*
    public void m(int a){
    }if (a==0){
    throw  new ExcepcionPersonalizada("error: valor cero");
}
    */
}
