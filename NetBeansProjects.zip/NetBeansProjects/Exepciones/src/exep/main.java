
package exep;

/**
 *
 * @author labso06
 */
public class main {
    public static void main(String[] args) {
        try {
            throw new ExcepcionPersonalizada("mi excepcion personalizada");
        } catch (ExcepcionPersonalizada e) {
            System.out.println("excepcion personalizada");
            System.out.println(e.getMessage());
        }
    }
}
